 @extends('layouts.main-layout.app')
 @section('title', 'Rekap Nilai Global')
 @section('content')

     <div class="card mb-4">
         <div class="card-body">e

             <div class="table-responsive">

                 <table class="datatable table">
                     <thead>
                         <tr>
                             <th>Ujian</th>
                             <th>NIS</th>
                             <th>Nama</th>
                             <th>Kelas</th>
                             <th>Jlh Soal</th>
                             <th>Jlh Benar</th>
                             <th>Jlh Salah</th>
                             <th>Jlh Tidak Jawab</th>
                             <th>Nilai</th>
                             {{-- <th>Rank</th>
                             <th>Rank2</th> --}}
                             <th>Created at</th>
                             <th>Action</th>
                         </tr>
                     </thead>
                     <tbody>
                         @foreach ($data as $r)
                             <tr>
                                 <td>{{ $r->kode_ujian . ' - ' . $r->matapelajaran }}</td>
                                 <td>{{ $r->nis }}</td>
                                 <td>{{ $r->nama_siswa }}</td>
                                 <td>{{ $r->kelas }}</td>
                                 <td>{{ $r->jlh_soal }}</td>
                                 <td>{{ $r->jlh_jawab_benar }}</td>
                                 <td>{{ $r->jlh_jawab_salah }}</td>
                                 <td>{{ $r->jlh_tidak_jawab }}</td>
                                 <td>{{ $r->nilai }}</td>
                                 {{-- <td>{{ $r->rank }}</td>
                                 <td>{{ $r->rank2 }}</td> --}}

                                 <td>{{ \Carbon\Carbon::parse($r->created_at)->isoFormat('dddd, D MMM YYYY, HH:mm:ss') }}
                                 </td>
                                 <td>

                                 </td>

                             </tr>
                         @endforeach
                     </tbody>

                 </table>
             </div>
         </div>
     </div>
 @endsection
